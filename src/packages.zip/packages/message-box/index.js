/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import { MessageBox } from './src/main'
export default MessageBox
