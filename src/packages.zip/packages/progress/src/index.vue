<template>
  <div class="fg-progress">fg-table-component</div>
</template>

<script>
export default {
  name: 'FgProgress',
}
</script>

<style lang="scss">
.fg-progress {
}
</style>
