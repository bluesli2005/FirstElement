/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgLoading from './src/index'

FgLoading.install = function (Vue) {
  Vue.component(FgLoading.name, FgLoading)
}

export default FgLoading
