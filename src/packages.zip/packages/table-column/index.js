import FgTableColumn from '../table/src/TableColumn'
FgTableColumn.install = function (Vue) {
  Vue.component(FgTableColumn.name, FgTableColumn)
}

export default FgTableColumn
