/**
 * Date: 2020-09-11 17:16
 */
import Tabs from './src/index'

Tabs.install = function (Vue) {
  Vue.component(Tabs.name, Tabs)
}

export default Tabs
