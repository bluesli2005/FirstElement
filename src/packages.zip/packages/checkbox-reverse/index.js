/**
 * Created by TrangCTT2
 * Date: 2021-06-02 17:57
 */
import FgCheckboxReverse from './src/index'

FgCheckboxReverse.install = function (Vue) {
  Vue.component(FgCheckboxReverse.name, FgCheckboxReverse)
}

export default FgCheckboxReverse
