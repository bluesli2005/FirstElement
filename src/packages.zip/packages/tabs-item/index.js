import FgTabsItem from '../tabs/src/TabsItem.vue'
FgTabsItem.install = function (Vue) {
  Vue.component(FgTabsItem.name, FgTabsItem)
}

export default FgTabsItem
