/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgSelect from './src/index'

FgSelect.install = function (Vue) {
  Vue.component(FgSelect.name, FgSelect)
}

export default FgSelect
