/**
 * author: bunhyoLI
 */
import FgTable from './src/index'

FgTable.install = function (Vue) {
  Vue.component(FgTable.name, FgTable)
}

export default FgTable
