/**
 * Created by Capricorncd.
 * Date: 2020-08-05 12:00
 */
import FgPopup from './src/index'

FgPopup.install = function (Vue) {
  Vue.component(FgPopup.name, FgPopup)
}

export default FgPopup
