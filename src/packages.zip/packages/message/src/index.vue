<template>
  <div class="fg-message">fg-message</div>
</template>

<script>
export default {
  name: 'FgMessage',
}
</script>

<style lang="scss">
.fg-message {
}
</style>
