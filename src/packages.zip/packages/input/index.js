/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgInput from './src/index'

FgInput.install = function (Vue) {
  Vue.component(FgInput.name, FgInput)
}

export default FgInput
