/**
 * Created by Wenbiao Li
 * Date: 2020-12-11 17:57
 */
import FgMultiSelect from './src/index'

FgMultiSelect.install = function (Vue) {
  Vue.component(FgMultiSelect.name, FgMultiSelect)
}

export default FgMultiSelect
