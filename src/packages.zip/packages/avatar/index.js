/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgAvatar from './src/index'

FgAvatar.install = function (Vue) {
  Vue.component(FgAvatar.name, FgAvatar)
}

export default FgAvatar
