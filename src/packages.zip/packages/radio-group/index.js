/**
 * Created by Capricorncd.
 * Date: 2020-08-23 13:11
 */
import RadioGroup from './src/index'

RadioGroup.install = function (Vue) {
  Vue.component(RadioGroup.name, RadioGroup)
}

export default RadioGroup
