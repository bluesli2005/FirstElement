/**
 * Created by Capricorncd.
 * Date: 2020-08-05 16:03
 */
import FgCol from './src/col'

FgCol.install = function (Vue) {
  Vue.component(FgCol.name, FgCol)
}

export default FgCol
