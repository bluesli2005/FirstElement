/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgRow from './src/index'

FgRow.install = function (Vue) {
  Vue.component(FgRow.name, FgRow)
}

export default FgRow
