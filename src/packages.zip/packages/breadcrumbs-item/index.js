/**
 * author: bunhyoLI
 */
import FgBreadcrumbsItem from '../breadcrumbs/src/BreadcrumbsItem.vue'

FgBreadcrumbsItem.install = function (Vue) {
  Vue.component(FgBreadcrumbsItem.name, FgBreadcrumbsItem)
}

export default FgBreadcrumbsItem
