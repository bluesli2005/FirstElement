/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgIcon from './src/index'

FgIcon.install = function (Vue) {
  Vue.component(FgIcon.name, FgIcon)
}

export default FgIcon
