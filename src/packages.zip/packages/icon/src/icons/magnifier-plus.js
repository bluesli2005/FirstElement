/**
 * Created by Capricorncd.
 * Date: 2020-09-04 17:19
 */
export const magnifierPlus = {
  w: 14,
  h: 14,
  i: [
    '<g transform="translate(7804 12814)"><path d="M14,12.767,11.094,9.862a6.029,6.029,0,0,0,1.233-3.7A6.126,6.126,0,0,0,6.164,0,6.126,6.126,0,0,0,0,6.164a6.126,6.126,0,0,0,6.164,6.164,6.029,6.029,0,0,0,3.7-1.233L12.767,14ZM1.761,6.164a4.36,4.36,0,0,1,4.4-4.4,4.36,4.36,0,0,1,4.4,4.4,4.36,4.36,0,0,1-4.4,4.4A4.36,4.36,0,0,1,1.761,6.164Z" transform="translate(-7804 -12814)" fill="currentColor"/><g transform="translate(-0.384 0.316)"><rect width="6" height="1.5" transform="translate(-7800.316 -12809.066)" fill="currentColor"/><rect width="6" height="1.5" transform="translate(-7796.566 -12811.316) rotate(90)" fill="currentColor"/></g></g>',
  ],
}
