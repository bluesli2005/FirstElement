/**
 * Created by Capricorncd.
 * Date: 2020-08-18 10:27
 */
export const exclamationCircle = {
  w: 12,
  h: 12,
  i: [
    {
      t: 'path',
      a: {
        d:
          'M1242,10255a6,6,0,1,1,6-6A6.006,6.006,0,0,1,1242,10255Zm0-4a1,1,0,1,0,1,1A1,1,0,0,0,1242,10251Zm0-6a1,1,0,0,0-1,1v3a1,1,0,0,0,2,0v-3A1,1,0,0,0,1242,10245Z',
        transform: 'translate(-1236.001 -10242.999)',
      },
    },
  ],
}
