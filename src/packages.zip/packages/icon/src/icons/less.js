/**
 * Created by Capricorncd.
 * Date: 2020-08-18 09:52
 */
export const less = {
  w: 8,
  h: 1.6,
  i: [
    {
      t: 'path',
      a: {
        d: 'M0,3.2H8V4.8H0Z',
        transform: 'translate(0 -3.2)',
      },
    },
  ],
}
