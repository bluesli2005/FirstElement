/**
 * Created by Capricorncd.
 * Date: 2020-08-18 10:34
 */
export const exclamation = {
  w: 2.002,
  h: 8.001,
  i: [
    {
      t: 'path',
      a: {
        d:
          'M1236,10250a1,1,0,1,1,1,1A1,1,0,0,1,1236,10250Zm0-3v-3a1,1,0,1,1,2,0v3a1,1,0,1,1-2,0Z',
        transform: 'translate(-1236 -10242.999)',
      },
    },
  ],
}
