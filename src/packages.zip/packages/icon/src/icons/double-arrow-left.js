/**
 * Created by Capricorncd.
 * Date: 2020-08-28 14:52
 */
// double arrow left
export const doubleArrowLeft = {
  w: 8.934,
  h: 7.999,
  i: [
    {
      t: 'path',
      a: {
        d:
          'M6624,5780l4-4,.933.933-3.067,3.066,3.067,3.067L6628,5784Zm-4,0,4-4,.933.933-3.066,3.066,3.066,3.067L6624,5784Z',
        transform: 'translate(-6620 -5776)',
      },
    },
  ],
}
