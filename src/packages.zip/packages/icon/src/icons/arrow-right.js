/**
 * Created by Capricorncd.
 * Date: 2020-08-14 14:28
 */
import { children } from './arrow-left'

export const arrowRight = {
  w: 6.9,
  h: 11.19,
  i: children,
}
