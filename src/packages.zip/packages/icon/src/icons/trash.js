/**
 * Created by Capricorncd.
 * Date: 2020-08-17 10:08
 */
export const trash = {
  w: 12,
  h: 12.874,
  i: [
    {
      t: 'g',
      a: {
        transform: 'translate(-17.379)',
      },
      c: [
        {
          t: 'g',
          a: {
            transform: 'translate(17.379 2.416)',
          },
          c: [
            {
              t: 'g',
              a: {
                transform: 'translate(0)',
              },
              c: [
                {
                  t: 'path',
                  a: {
                    d: 'M306.34,175.089l-1.26-.033-.273,5.326,1.26.033Z',
                    transform: 'translate(-297.785 -172.506)',
                  },
                },
                {
                  t: 'rect',
                  a: {
                    width: '1.26',
                    height: '5.312',
                    transform: 'translate(5.37 2.573)',
                  },
                },
                {
                  t: 'path',
                  a: {
                    d: 'M159.952,180.375l-.273-5.326-1.26.033.273,5.326Z',
                    transform: 'translate(-154.974 -172.499)',
                  },
                },
                {
                  t: 'path',
                  a: {
                    d:
                      'M17.379,76.867v.964H18.43l.834,9.054a.5.5,0,0,0,.5.44h7.21a.5.5,0,0,0,.5-.44l.834-9.054h1.068v-.964Zm9.135,9.494H20.227l-.785-8.53H27.3Z',
                    transform: 'translate(-17.379 -76.867)',
                  },
                },
              ],
            },
          ],
        },
        {
          t: 'g',
          a: {
            transform: 'translate(20.27)',
          },
          c: [
            {
              t: 'path',
              a: {
                d:
                  'M162.244,0h-4.118a1.052,1.052,0,0,0-1.05,1.05v2h1.26V1.26h3.7V3.046h1.26v-2A1.052,1.052,0,0,0,162.244,0Z',
                transform: 'translate(-157.076)',
              },
            },
          ],
        },
      ],
    },
  ],
}
