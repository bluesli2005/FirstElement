/**
 * Created by Capricorncd.
 * Date: 2020-08-14 14:32
 */
export const download = {
  w: 12,
  h: 14,
  i: [
    {
      t: 'path',
      a: {
        d: 'M13,10.778H10.75V3H9.25v7.778H7l3,3.111ZM4,15.444V17H16V15.444Z',
        transform: 'translate(-4 -3)',
      },
    },
  ],
}
