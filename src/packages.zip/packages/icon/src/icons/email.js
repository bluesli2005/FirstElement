/**
 * Created by Capricorncd.
 * Date: 2020-08-17 18:17
 */
export const email = {
  w: 10,
  h: 7.428,
  i: [
    {
      t: 'g',
      a: {
        transform: 'translate(0.337)',
      },
      c: [
        {
          t: 'path',
          a: {
            d: 'M430.657,165.628h-9.32L426,169.261l4.712-3.623Z',
            transform: 'translate(-421.337 -165.628)',
          },
        },
      ],
    },
    {
      t: 'g',
      a: {
        transform: 'translate(0 0.598)',
      },
      c: [
        {
          t: 'path',
          a: {
            d:
              'M426.4,170.041a.344.344,0,0,1-.452,0l-4.772-4.126v6.455a.365.365,0,0,0,.355.375h9.287a.367.367,0,0,0,.357-.375v-6.4Z',
            transform: 'translate(-421.175 -165.915)',
          },
        },
      ],
    },
  ],
}
