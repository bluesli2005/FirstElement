/**
 * Created by Capricorncd.
 * Date: 2020-08-21 10:27
 */
export const hook = {
  w: 9.192,
  h: 6.441,
  i: [
    {
      t: 'path',
      a: {
        d: 'M12427.426-16876.428l3.306,3.408,4.817-4.842',
        transform: 'translate(-12426.888 16878.391)',
        fill: 'none',
        stroke: 'currentColor',
        strokeWidth: '1.5',
      },
    },
  ],
}
