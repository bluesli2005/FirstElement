/**
 * Created by Capricorncd.
 * Date: 2020-08-14 14:36
 */
export const plus = {
  w: 12,
  h: 12,
  i: [
    {
      t: 'line',
      a: {
        y2: '12',
        transform: 'translate(6)',
        fill: 'none',
        strokeWidth: '2',
        stroke: 'currentColor',
      },
    },
    {
      t: 'line',
      a: {
        x1: '12',
        transform: 'translate(0 6)',
        fill: 'none',
        strokeWidth: '2',
        stroke: 'currentColor',
      },
    },
  ],
}
