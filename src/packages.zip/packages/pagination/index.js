/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgPagination from './src/index'

FgPagination.install = function (Vue) {
  Vue.component(FgPagination.name, FgPagination)
}

export default FgPagination
