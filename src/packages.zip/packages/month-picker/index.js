/**
 * author: bunhyoLI
 */
import FgDatePicker from './src/index'

FgDatePicker.install = function (Vue) {
  Vue.component(FgDatePicker.name, FgDatePicker)
}

export default FgDatePicker
