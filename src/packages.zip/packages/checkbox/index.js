/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgCheckbox from './src/index'

FgCheckbox.install = function (Vue) {
  Vue.component(FgCheckbox.name, FgCheckbox)
}

export default FgCheckbox
