import FgCustomerRank from './src/index'

FgCustomerRank.install = function (Vue) {
  Vue.component(FgCustomerRank.name, FgCustomerRank)
}

export default FgCustomerRank
