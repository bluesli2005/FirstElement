/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgForm from './src/index'

FgForm.install = function (Vue) {
  Vue.component(FgForm.name, FgForm)
}

export default FgForm
