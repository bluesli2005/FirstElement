/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import Table from './src/index'

Table.install = function (Vue) {
  Vue.component(Table.name, Table)
}

export default Table
