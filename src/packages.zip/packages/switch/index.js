/**
 * author: bunhyoLI
 */
import FgSwitch from './src/index'

FgSwitch.install = function (Vue) {
  Vue.component(FgSwitch.name, FgSwitch)
}

export default FgSwitch
