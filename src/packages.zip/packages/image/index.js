/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgImage from './src/index'

FgImage.install = function (Vue) {
  Vue.component(FgImage.name, FgImage)
}

export default FgImage
