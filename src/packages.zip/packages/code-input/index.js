/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import CodeInput from './src/index'

CodeInput.install = function (Vue) {
  Vue.component(CodeInput.name, CodeInput)
}

export default CodeInput
