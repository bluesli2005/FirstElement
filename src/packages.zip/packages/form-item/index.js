/**
 * Created by Capricorncd.
 * Date: 2020-07-30 17:57
 */
import FgFormItem from '../form/src/form-item'
FgFormItem.install = function (Vue) {
  Vue.component(FgFormItem.name, FgFormItem)
}

export default FgFormItem
