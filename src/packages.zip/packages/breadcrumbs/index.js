/**
 * author: bunhyoLI
 */
import FgBreadcrumbs from './src/index'

FgBreadcrumbs.install = function (Vue) {
  Vue.component(FgBreadcrumbs.name, FgBreadcrumbs)
}

export default FgBreadcrumbs
